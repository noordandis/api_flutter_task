class ApiEndpoint {
  static const String baseUrl="https://fakestoreapi.com";
  static const String products="/products";
  static String getAllProduct ()=>'$products/';
}